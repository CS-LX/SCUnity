// Copyright (c) Six Labors.
// Licensed under the Six Labors Split License.

using System.Runtime.CompilerServices;

namespace SixLabors.ImageSharp.ColorSpaces.Conversion;

/// <summary>
/// Color converter between <see cref="LinearRgb"/> and <see cref="Rgb"/>.
/// </summary>
internal static class LinearRgbToRgbConverter
{
    /// <summary>
    /// Performs the conversion from the <see cref="LinearRgb"/> input to an instance of <see cref="Rgb"/> type.
    /// </summary>
    /// <param name="input">The input color instance.</param>
    /// <returns>The converted result.</returns>
    [MethodImpl(InliningOptions.ShortMethod)]
    public static Rgb Convert(in LinearRgb input) =>
        new(
            r: input.WorkingSpace.Compress(input.R),
            g: input.WorkingSpace.Compress(input.G),
            b: input.WorkingSpace.Compress(input.B),
            workingSpace: input.WorkingSpace);
}
