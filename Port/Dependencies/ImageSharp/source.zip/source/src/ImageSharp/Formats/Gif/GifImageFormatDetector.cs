﻿// Copyright (c) Six Labors.
// Licensed under the Six Labors Split License.

using System.Diagnostics.CodeAnalysis;

namespace SixLabors.ImageSharp.Formats.Gif;

/// <summary>
/// Detects gif file headers
/// </summary>
public sealed class GifImageFormatDetector : IImageFormatDetector
{
    /// <inheritdoc/>
    public int HeaderSize => 6;

    /// <inheritdoc/>
    public bool TryDetectFormat(ReadOnlySpan<byte> header, [NotNullWhen(true)] out IImageFormat? format)
    {
        format = this.IsSupportedFileFormat(header) ? GifFormat.Instance : null;
        return format != null;
    }

    private bool IsSupportedFileFormat(ReadOnlySpan<byte> header)
    {
        return header.Length >= this.HeaderSize &&
               header[0] == 0x47 && // G
               header[1] == 0x49 && // I
               header[2] == 0x46 && // F
               header[3] == 0x38 && // 8
              (header[4] == 0x39 || header[4] == 0x37) && // 9 or 7
               header[5] == 0x61;   // a
    }
}
